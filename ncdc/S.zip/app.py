import os
from pathlib import Path
from flask import Flask, render_template

app = Flask(__name__)


def get_raw(rootdir):
    return len([name for name in os.listdir(rootdir) \
                if os.path.isfile(os.path.join(rootdir, name))])


def count_files(rootdir):
    files = []
    for path in Path(rootdir).iterdir():
        if path.is_dir() and path.name != "niewykryte":
            files.append(Folder(str(path.name), len([name for name in os.listdir(path) \
                                                     if os.path.isfile(os.path.join(path, name))])))
    return files


def get_niewykryte(rootdir):
    return len([name for name in os.listdir(rootdir+"/niewykryte") \
         if os.path.isfile(os.path.join(rootdir+"/niewykryte", name))])


class Folder:
    def __init__(self, bib, photos):
        self.bib = bib
        self.photos = photos


@app.route('/')
def index():
    PHOTOS="opt/photos"
    RAW = "opt/raw"
    folder_stats = count_files(PHOTOS)
    niewykryte = get_niewykryte(PHOTOS)
    raw = get_raw(RAW)
    wykryte = raw-niewykryte
    procent = wykryte*100/raw
    return render_template('index.html', folder_stats=folder_stats, niewykryte=niewykryte, wykryte=wykryte, raw=raw, procent=procent)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
